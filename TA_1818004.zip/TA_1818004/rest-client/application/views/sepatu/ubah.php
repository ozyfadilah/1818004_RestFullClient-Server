<div class="container">

    <div class="row mt-3">
        <div class="col-md-6">

            <div class="card">
                <div class="card-header">
                    Form Ubah Data Sepatu
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <input type="hidden" name="id" value="<?= $tb_sepatu['id']; ?>">
                        <div class="form-group">
                            <label for="nama_sepatu">Nama Sepatu</label>
                            <input type="text" name="nama_sepatu" class="form-control" id="nama_sepatu" value="<?= $tb_sepatu['nama_sepatu']; ?>">
                            <small class="form-text text-danger"><?= form_error('nama_sepatu'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="ukuran">Ukuran</label>
                            <input type="text" name="ukuran" class="form-control" id="ukuran" value="<?= $tb_sepatu['ukuran']; ?>">
                            <small class="form-text text-danger"><?= form_error('ukuran'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="warna">Warna</label>
                            <input type="text" name="warna" class="form-control" id="warna" value="<?= $tb_sepatu['warna']; ?>">
                            <small class="form-text text-danger"><?= form_error('warna'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="stok">Harga</label>
                            <input type="text" name="harga" class="form-control" id="harga" value="<?= $tb_sepatu['harga']; ?>">
                            <small class="form-text text-danger"><?= form_error('stok'); ?></small>
                        </div>
                        <button type="submit" name="ubah" class="btn btn-primary float-right">Ubah Data</button>
                        <a href="<?= base_url(); ?>barang" class="btn btn-primary ">Kembali</a>
                    </form>
                </div>
            </div>


        </div>
    </div>

</div>