<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">

            <div class="card">
                <div class="card-header">
                    Detail Data Sepatu
                </div>
                <div class="card-body">
                    <h4 class="card-title">Id : <?= $tb_sepatu['id']; ?></h4>
                    <h6 class="card-title">Nama Sepatu : <?= $tb_sepatu['nama_sepatu']; ?></h6>
                    <p class="card-text">Ukuran : <?= $tb_sepatu['ukuran']; ?></p>
                    <p class="card-text">Warna : <?= $tb_sepatu['warna']; ?></p>
                    <p class="card-text">Harga : <?= $tb_sepatu['harga']; ?></p>
                    <a href="<?= base_url(); ?>sepatu" class="btn btn-primary">Kembali</a>
                </div>
            </div>
        
        </div>
    </div>
</div>