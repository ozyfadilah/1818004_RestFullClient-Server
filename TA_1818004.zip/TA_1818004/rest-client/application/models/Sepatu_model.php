<?php 
use GuzzleHttp\Client;

class Sepatu_model extends CI_model {

    private $_client;

    public function __construct()
    {
        $this->_client = new Client([
            'base_uri' => 'http://localhost/TA_1818004/rest-server/index.php/',
            'auth' => ['ozy','12345']
        ]);
    }

    public function __getAllSepatu()
    {
        //return $this->db->get('tb_sepatu')->result_array();

        $response = $this->_client->request('GET', 'Sepatu', [
            'query' => [
                'wpu-key' => '1818004'
            ]
            ]);

            $result = json_decode($response->getBody()->getContents(), true);

            return $result['data'];
    }

    public function getAllSepatu()
    {
        //return $this->db->get('tb_sepatu')->result_array();

         $response = $this->_client->request('GET', 'sepatu',[
          'query' => [
              'wpu-key' => '1818004'
          ]   
         ]);
         $result = json_decode($response->getBody()->getContents(), true);

            return $result['data'];
    }

    public function getSepatuById($id)
    {
        //return $this->db->get_where('tb_sepatu', ['id' => $id])->row_array();
        $response = $this->_client->request('GET', 'sepatu',[
            'query' => [
                'wpu-key' => '1818004',
                'id' => $id
            ]   
           ]);
           $result = json_decode($response->getBody()->getContents(), true);
  
              return $result['data'][0];


    }

    public function tambahDataSepatu()
    {
        $data = [
            "id" => $this->input->post('id', true),
            "nama_sepatu" => $this->input->post('nama_sepatu', true),
            "ukuran" => $this->input->post('ukuran', true),
            "warna" => $this->input->post('warna', true),
            "harga" => $this->input->post('harga', true),
            'wpu-key' => '1818004'
        ];
        $response = $this->_client->request('POST', 'sepatu',[

                
                'form_params' => $data   
           ]);
           $result = json_decode($response->getBody()->getContents(), true);
  
              return $result;



        //$this->db->insert('tb_sepatu', $data);
    }

    public function hapusDataSepatu($id)
    {
        // $this->db->where('id', $id);
        //$this->db->delete('tb_sepatu', ['id' => $id]);
        $response = $this->_client->request('DELETE', 'sepatu',[

                
            'form_params' => [
                'id' => $id,
                'wpu-key' => '1818004'
            ]  
       ]);
    }

   

    public function ubahDataSepatu()
    {
        $data = [
            "id" => $this->input->post('id', true),
            "nama_sepatu" => $this->input->post('nama_sepatu', true),
            "ukuran" => $this->input->post('ukuran', true),
            "warna" => $this->input->post('warna', true),
            "harga" => $this->input->post('harga', true),
            'wpu-key' => '1818004'
        ];

        //$this->db->where('id', $this->input->post('id'));
        //$this->db->update('tb_sepatu', $data);
        $response = $this->_client->request('PUT', 'sepatu',[

                
            'form_params' => $data   
       ]);
       $result = json_decode($response->getBody()->getContents(), true);

          return $result;
    }

    public function cariDataSepatu()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('id', $keyword);
        $this->db->or_like('nama_sepatu', $keyword);
        $this->db->or_like('ukuran', $keyword);
        $this->db->or_like('warna', $keyword);
        $this->db->or_like('harga', $keyword);
        return $this->db->get('tb_sepatu')->result_array();
    }
}