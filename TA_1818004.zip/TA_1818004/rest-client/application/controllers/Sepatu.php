<?php

class Sepatu extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Sepatu_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['judul'] = 'Daftar Sepatu';
        $data['tb_sepatu'] = $this->Sepatu_model->getAllSepatu();
        if( $this->input->post('keyword') ) {
            $data['tb_sepatu'] = $this->Sepatu_model->cariDataSepatu();
        }
        $this->load->view('templates/header', $data);
        $this->load->view('sepatu/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah()
    {
        $data['judul'] = 'Form Tambah Data Sepatu';
        $this->form_validation->set_rules('id', 'Id', 'required');
        $this->form_validation->set_rules('nama_sepatu', 'Nama Sepatu', 'required');
        $this->form_validation->set_rules('ukuran', 'Ukuran', 'required');
        $this->form_validation->set_rules('warna', 'Warna', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required|numeric');
        //$this->form_validation->set_rules('nrp', 'NRP', 'required|numeric');
        //$this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('sepatu/tambah');
            $this->load->view('templates/footer');
        } else {
            $this->Sepatu_model->tambahDataSepatu();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('sepatu');
        }
    }

    public function hapus($id)
    {
        $this->Sepatu_model->hapusDataSepatu($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('sepatu');
    }

    public function detail($id)
    {
        $data['judul'] = 'Detail Data Sepatu';
        $data['tb_sepatu'] = $this->Sepatu_model->getSepatuById($id);
        $this->load->view('templates/header', $data);
        $this->load->view('sepatu/detail', $data);
        $this->load->view('templates/footer');
    }

    public function ubah($id)
    {
        $data['judul'] = 'Form Ubah Data Sepatu';
        $data['tb_sepatu'] = $this->Sepatu_model->getSepatuById($id);
        //$data['jurusan'] = ['Teknik Informatika', 'Teknik Mesin', 'Teknik Planologi', 'Teknik Pangan', 'Teknik Lingkungan'];
        $this->form_validation->set_rules('nama_sepatu', 'Nama Sepatu', 'required');
        $this->form_validation->set_rules('ukuran', 'Ukuran', 'required');
        $this->form_validation->set_rules('warna', 'Warna', 'required|required');
        $this->form_validation->set_rules('harga', 'Harga', 'required|numeric');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('sepatu/ubah', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Sepatu_model->ubahDataSepatu();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('sepatu');
        }
    }

}
