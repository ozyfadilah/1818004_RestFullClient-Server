-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 22 Des 2021 pada 06.11
-- Versi server: 10.4.21-MariaDB
-- Versi PHP: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_sepatu`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_sepatu`
--

CREATE TABLE `tb_sepatu` (
  `id` int(11) NOT NULL,
  `nama_sepatu` varchar(255) NOT NULL,
  `ukuran` int(11) NOT NULL,
  `warna` varchar(255) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_sepatu`
--

INSERT INTO `tb_sepatu` (`id`, `nama_sepatu`, `ukuran`, `warna`, `harga`) VALUES
(1, 'adidas', 40, 'putih', 250000),
(2, 'nike', 41, 'merah', 400000),
(3, 'puma', 41, 'hitam', 500000),
(4, 'ortuseight', 42, 'biru', 450000),
(5, 'specs', 39, 'orange', 450000);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_sepatu`
--
ALTER TABLE `tb_sepatu`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
